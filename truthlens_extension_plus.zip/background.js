
// Background handles: site dumps, storage updates, badge, context menu, commands, and periodic re-sync.
const ORIGIN_WILDCARD = "https://*.app.github.dev/*";

function setBadge(text, color) {
  if (chrome.action && chrome.action.setBadgeText) {
    chrome.action.setBadgeText({ text });
    chrome.action.setBadgeBackgroundColor({ color: color || '#6366f1' });
  }
}

async function computeBadge() {
  const all = await chrome.storage.local.get(['fc_site_cache']);
  const db = all.fc_site_cache;
  if (!db || !db.email) { setBadge('', null); return; }
  // Show remaining checks for Basic, or '∞' for Premium
  const email = db.email;
  const base = (db.plans||{})[email] || 'Basic';
  const paid = (db.paid||{})[email] === true;
  const exp = (db.expires||{})[email] || 0;
  const premium = (base==='Premium' && paid && Date.now()<exp);
  if (premium) { setBadge('∞', '#10b981'); return; }
  const key = `${email}-${new Date().toISOString().slice(0,10)}`;
  const used = (db.usage||{})[key] || 0;
  const left = Math.max(0, 3-used);
  setBadge(String(left), left>0 ? '#f59e0b' : '#ef4444');
}

// Receive dump from content script (even if popup closed)
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'FC_SITE_DUMP' && msg.payload) {
    chrome.storage.local.set({
      fc_site_cache: msg.payload,
      last_sync: Date.now()
    }, () => {
      computeBadge();
      chrome.runtime.sendMessage({ type: 'FC_STORAGE_UPDATED' });
      sendResponse && sendResponse({ ok: true });
    });
    return true;
  }
});

// Watch storage changes to keep badge fresh
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (changes.fc_site_cache || changes.usage)) computeBadge();
});

// Context menu for selection -> prefill popup
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'tl_check_selection',
    title: 'Check selection with TruthLens',
    contexts: ['selection']
  });
  // set initial badge
  computeBadge();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'tl_check_selection' && info.selectionText) {
    chrome.storage.local.set({ pending_fact_text: info.selectionText }, () => {
      chrome.action.openPopup();
    });
  }
});

// Commands (keyboard shortcuts)
chrome.commands.onCommand.addListener(async (command) => {
  if (command === 'tl_check_selection') chrome.action.openPopup();
  if (command === 'tl_refresh_link') reimportFromTabs();
});

// Periodic refresh (hourly) to keep link warm
chrome.alarms.create('tl_hourly_refresh', { periodInMinutes: 60 });
chrome.alarms.onAlarm.addListener((a) => { if (a.name==='tl_hourly_refresh') reimportFromTabs(); });

async function reimportFromTabs() {
  // Ping any Codespaces pages to dump localStorage
  const tabs = await chrome.tabs.query({ url: ORIGIN_WILDCARD });
  for (const t of tabs) chrome.tabs.sendMessage(t.id, { type: 'FC_PING' });
}
