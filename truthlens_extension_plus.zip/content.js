// On page load, try to export session storage to the extension.
(function dumpNow(){
  try{
    const raw = localStorage.getItem('fc_site');
    if(!raw) return;
    const parsed = JSON.parse(raw);
    if(parsed && typeof parsed === 'object' && (parsed.email || parsed.token)){
      chrome.runtime.sendMessage({ type: 'FC_SITE_DUMP', payload: parsed }, (resp)=>{});
    }
  }catch(e){}
})();

// Respond to pings from popup/background to (re)send the data
chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if(msg && msg.type === 'FC_PING'){
    try{
      const raw = localStorage.getItem('fc_site');
      if(raw){
        const parsed = JSON.parse(raw);
        chrome.runtime.sendMessage({ type: 'FC_SITE_DUMP', payload: parsed }, (resp)=>{});
      }
    }catch(e){}
    sendResponse && sendResponse({ ok: true });
  }
});
