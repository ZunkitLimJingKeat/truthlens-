
// === CONFIG ===
const OFFICIAL_ORIGIN = "https://organic-space-broccoli-69r6q6wjxxxj25qpx-5506.app.github.dev"; // Codespaces origin (scheme+host)
const INSTALL_URL = "https://organic-space-broccoli-69r6q6wjxxxj25qpx-5506.app.github.dev/fact-checker-website/index.html"; // full page to open

// === DOM ===
const $ = (s, r=document) => r.querySelector(s);
const el = {
  userBadge: $('#userBadge'),
  syncDot: $('#syncDot'),
  btnLink: $('#btnLink'),
  btnOpenSite: $('#btnOpenSite'),
  btnRefresh: $('#btnRefresh'),
  btnLogout: $('#btnLogout'),
  accountInfo: $('#accountInfo'),
  accEmail: $('#accEmail'),
  accPlan: $('#accPlan'),
  accStatus: $('#accStatus'),
  factSection: $('#factSection'),
  factText: $('#factText'),
  factBtn: $('#factBtn'),
  factOutput: $('#factOutput'),
  quotaNote: $('#quotaNote'),
  aiSection: $('#aiSection'),
  chatInput: $('#chatInput'),
  chatBtn: $('#chatBtn'),
  chatOutput: $('#chatOutput'),
  shareSection: $('#shareSection'),
  shareLink: $('#shareLink'),
  copyBtn: $('#copyBtn'),
  shareMeta: $('#shareMeta'),
  btnOpenInstall: $('#btnOpenInstall'),
  authMsg: $('#authMsg'),
  lastSync: $('#lastSync'),
  spinner: $('#spinner'),
  toast: $('#toast'),
};

function toast(msg){ el.toast.textContent = msg; el.toast.classList.add('show'); setTimeout(()=> el.toast.classList.remove('show'), 2200); }
function setDot(state){ el.syncDot.classList.remove('ok','warn','bad'); if(state) el.syncDot.classList.add(state); }
async function sha256Hex(str){
  const enc = new TextEncoder();
  const buf = await crypto.subtle.digest('SHA-256', enc.encode(str));
  return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
function daysLeft(ts){ if(!ts) return null; return Math.ceil((ts-Date.now())/(1000*60*60*24)); }
function quotaText(email, effPlan, usageMap){
  if (effPlan==='Premium') return 'Unlimited (Premium)';
  const key = `${email}-${new Date().toISOString().slice(0,10)}`;
  const used = (usageMap||{})[key] || 0;
  return `${Math.max(0,3-used)} checks remaining today (Basic)`;
}
function effectivePlan(db, email){
  const base = (db.plans||{})[email] || 'Basic';
  const paid = (db.paid||{})[email] === true;
  const exp = (db.expires||{})[email] || 0;
  if(base==='Premium' && paid && Date.now()<exp) return 'Premium';
  return 'Basic';
}

const NEWS_SOURCES = [
  "https://www.whitehouse.gov/news/",
  "https://www.reuters.com",
  "https://apnews.com/",
  "https://www.npr.org/sections/politics/",
  "https://www.bloomberg.com",
  "https://www.nytimes.com/section/politics",
  "https://www.cnbc.com/politics/",
  "https://finance.yahoo.com"
];
function tokenizeImportant(text){
  return (text.toLowerCase().match(/\b\w+\b/g)||[]).filter(w=>w.length>3);
}
async function fetchTextCORS(url){
  const proxy = 'https://r.jina.ai/http://';
  const safe = url.replace(/^https?:\/\//,'');
  try{
    const res = await fetch(proxy + safe, {cache:'no-store'});
    if(!res.ok) throw new Error('Fetch failed');
    return await res.text();
  }catch{ return ''; }
}
async function heuristicCheck(input){
  const words = tokenizeImportant(input);
  if(!words.length) return {label:'NEEDS REVIEW', report:'No meaningful words to compare.'};
  let bestScore = 0, bestLine = '', bestUrl = '', checked = 0;
  for(const src of NEWS_SOURCES){
    const txt = await fetchTextCORS(src);
    if(!txt) continue; checked++;
    const lines = txt.split(/\n+/).map(s=>s.trim()).filter(s=>s.split(' ').length>4);
    for(const line of lines.slice(0,400)){
      const low = line.toLowerCase();
      let score = 0;
      for(const w of words) if(low.includes(w)) score++;
      if(score>bestScore){ bestScore=score; bestLine=line; bestUrl=src; }
    }
  }
  const label = (bestScore>=2) ? 'VERIFIED' : 'NEEDS REVIEW';
  const report = bestLine
    ? `Matched: “${bestLine}”\nSource: ${bestUrl}\nMatch Score: ${bestScore} / ${words.length}\nChecked Sources: ${checked}`
    : `No strong match found. Checked Sources: ${checked}`;
  return {label, report};
}

const FACT_KB = {
  "inflation": "Inflation reduces purchasing power and often triggers central banks to raise interest rates to cool the economy.",
  "stock market": "Stock market movements are influenced by earnings reports, economic data, interest rate changes, and investor sentiment.",
  "cryptocurrency": "Cryptos like Bitcoin and Ethereum are highly volatile and respond to regulatory developments, adoption news, and technological upgrades.",
  "interest rates": "Interest rates are tools used by central banks to control inflation. Higher rates make borrowing costlier, slowing down economic activity.",
  "recession": "A recession is marked by economic decline, usually two quarters of negative GDP growth, often affecting jobs and investments.",
  "forex": "Forex markets are driven by rate differences, inflation, political stability, and trade flows.",
  "bonds": "When interest rates go up, bond prices typically fall. Yields reflect expected inflation and growth.",
  "gdp": "GDP measures a country’s total output and is used to gauge economic health and growth."
};

async function getExtState(){ return new Promise(res => chrome.storage.local.get(['fc_site_cache','pending_fact_text','last_sync'], v => res(v))); }
async function setExtState(patch){ return new Promise(res => chrome.storage.local.set(patch, res)); }
async function clearExtState(){ return new Promise(res => chrome.storage.local.remove(['fc_site_cache','pending_fact_text','last_sync'], res)); }

function setCollapsed(node, yes){ node.classList.toggle('collapsed', !!yes); }
function setBadge(email){ el.userBadge.textContent = email ? `Signed in: ${email}` : 'Guest'; }

function renderAccount(all){
  const db = all.fc_site_cache || null;
  const lastSync = all.last_sync ? new Date(all.last_sync).toLocaleTimeString() : '—';
  el.lastSync.textContent = `Last sync: ${lastSync}`;
  if(!db || !db.email){
    setBadge(null); el.authMsg.textContent = 'Not linked.'; setDot('warn');
    setCollapsed(el.accountInfo, true);
    setCollapsed(el.factSection, true);
    setCollapsed(el.aiSection, true);
    setCollapsed(el.shareSection, true);
    return;
  }
  const email = db.email;
  const plan = effectivePlan(db, email);
  setBadge(email); el.authMsg.textContent = 'Linked.'; setDot('ok');
  el.accEmail.textContent = email;
  el.accPlan.textContent = plan;
  if(plan==='Premium'){
    const d = daysLeft((db.expires||{})[email]||0);
    el.accStatus.innerHTML = `Premium — Active ✅ ${typeof d==='number' && d>=0 ? `(${d}d left)` : ''}`;
  }else{ el.accStatus.textContent = 'Basic'; }
  setCollapsed(el.accountInfo, false);
  setCollapsed(el.factSection, false);
  setCollapsed(el.shareSection, false);
  setCollapsed(el.aiSection, plan!=='Premium');
  el.quotaNote.textContent = quotaText(email, plan, db.usage||{});
}

async function importFromOpenTabs(){
  setDot('warn');
  // Ping all tabs under OFFICIAL_ORIGIN host
  const tabs = await chrome.tabs.query({ url: OFFICIAL_ORIGIN + '/*' });
  if(!tabs.length){
    // Fallback: try broad wildcard for Codespaces
    const wildTabs = await chrome.tabs.query({ url: 'https://*.app.github.dev/*' });
    wildTabs.forEach(t => chrome.tabs.sendMessage(t.id, {type:'FC_PING'}));
  }else{
    tabs.forEach(t => chrome.tabs.sendMessage(t.id, {type:'FC_PING'}));
  }
}

// Listen to background notices about storage changes to refresh UI
chrome.runtime.onMessage.addListener((msg)=>{
  if(msg && msg.type==='FC_STORAGE_UPDATED'){ init(); }
});

// Buttons
el.btnOpenSite.addEventListener('click', ()=> chrome.tabs.create({ url: INSTALL_URL }));
el.btnLink.addEventListener('click', async ()=>{ await importFromOpenTabs(); toast('Opened site. Log in, then click Refresh.'); });
el.btnRefresh.addEventListener('click', async ()=>{ await importFromOpenTabs(); toast('Requested fresh data from site…'); });
el.btnLogout.addEventListener('click', async ()=>{ await clearExtState(); toast('Unlinked.'); init(); });
el.copyBtn.addEventListener('click', async ()=>{
  if(!el.shareLink.value){ el.shareMeta.textContent = 'No link to copy yet.'; return; }
  try{ await navigator.clipboard.writeText(el.shareLink.value); el.shareMeta.textContent = 'Link copied to clipboard.'; }
  catch{ el.shareLink.select(); document.execCommand('copy'); el.shareMeta.textContent = 'Link copied (fallback).'; }
});
el.btnOpenInstall.addEventListener('click', ()=> chrome.tabs.create({ url: INSTALL_URL }));

// Core actions (unchanged in behavior)
el.factBtn.addEventListener('click', async ()=>{
  const all = await getExtState();
  const db = all.fc_site_cache;
  if(!db || !db.email){ el.factOutput.textContent = 'Please link your account first.'; return; }
  const email = db.email;
  const plan = effectivePlan(db, email);

  // Basic quota handling
  if(plan!=='Premium'){
    const key = `${email}-${new Date().toISOString().slice(0,10)}`;
    const used = (db.usage||{})[key] || 0;
    if(used >= 3){ el.factOutput.textContent = '❌ Daily quota exceeded (Free plan limit: 3 requests/day)'; return; }
    db.usage = db.usage || {}; db.usage[key] = used + 1;
    await setExtState({fc_site_cache: db});
  }
  const text = (el.factText.value||'').trim();
  if(!text){ el.factOutput.textContent = 'Please paste some text to check.'; return; }
  el.spinner.removeAttribute('aria-hidden');
  el.factOutput.textContent = 'Checking sources…';
  try{
    const res = await heuristicCheck(text);
    const quotaMsg = plan==='Premium' ? 'Unlimited checks (Premium).' : quotaText(email, plan, db.usage||{});
    el.factOutput.textContent = `Input: ${text}\nResult: ${res.label}\n${res.report}\n\n${quotaMsg}`;
    const h = await sha256Hex(email);
    el.shareLink.value = `https://fakechecker.org/session/${h.slice(0,8)}`;
    el.shareMeta.textContent = 'Share link is ready.';
    el.quotaNote.textContent = quotaMsg;
  }catch(err){ el.factOutput.textContent = String(err); } finally { el.spinner.setAttribute('aria-hidden','true'); }
});

el.chatBtn.addEventListener('click', async ()=>{
  const all = await getExtState();
  const db = all.fc_site_cache;
  if(!db || !db.email){ el.chatOutput.textContent = 'Link your account first.'; return; }
  const email = db.email;
  if(effectivePlan(db, email)!=='Premium'){ el.chatOutput.textContent = '🔒 AI Assistant is Premium only.'; return; }
  const q = (el.chatInput.value||'').trim();
  if(!q){ el.chatOutput.textContent='Type a question to ask the assistant.'; return; }
  const t = q.toLowerCase(); let best=null, score=0;
  Object.keys(FACT_KB).forEach(k=>{ let s=0; k.split(' ').forEach(w=>{ if(t.includes(w)) s++; }); if(s>score){ score=s; best=k; } });
  el.chatOutput.textContent = best
    ? `You: ${q}\n🧠 Topic: ${best.toUpperCase()}\n${FACT_KB[best]}`
    : `AI: I'm analyzing "${q}", but couldn't match it to a known finance topic. Try terms like "inflation", "crypto", or "interest rates".`;
});

// On open, if context-menu put text here
async function applyPending() {
  const all = await getExtState();
  if(all.pending_fact_text) {
    el.factText.value = all.pending_fact_text;
    await setExtState({pending_fact_text: null});
    setCollapsed(el.factSection, false);
  }
}

async function init(){
  const all = await getExtState();
  renderAccount(all);
  await applyPending();
}
init();
